﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.FormPanel = New Guna.UI2.WinForms.Guna2Panel()
        Me.MinimiseBox = New Guna.UI2.WinForms.Guna2ControlBox()
        Me.CloseBox = New Guna.UI2.WinForms.Guna2ControlBox()
        Me.FormLabel = New System.Windows.Forms.Label()
        Me.FormDrag = New Guna.UI2.WinForms.Guna2DragControl(Me.components)
        Me.LabelDrag = New Guna.UI2.WinForms.Guna2DragControl(Me.components)
        Me.Username = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Password = New Guna.UI2.WinForms.Guna2TextBox()
        Me.MainButton = New Guna.UI2.WinForms.Guna2Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.FormPanel.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FormPanel
        '
        Me.FormPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.FormPanel.Controls.Add(Me.PictureBox1)
        Me.FormPanel.Controls.Add(Me.MinimiseBox)
        Me.FormPanel.Controls.Add(Me.CloseBox)
        Me.FormPanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.FormPanel.FillColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.FormPanel.Location = New System.Drawing.Point(0, 0)
        Me.FormPanel.Name = "FormPanel"
        Me.FormPanel.ShadowDecoration.BorderRadius = 3
        Me.FormPanel.ShadowDecoration.Depth = 10
        Me.FormPanel.ShadowDecoration.Enabled = True
        Me.FormPanel.ShadowDecoration.Parent = Me.FormPanel
        Me.FormPanel.Size = New System.Drawing.Size(209, 25)
        Me.FormPanel.TabIndex = 1
        '
        'MinimiseBox
        '
        Me.MinimiseBox.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MinimiseBox.Animated = True
        Me.MinimiseBox.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox
        Me.MinimiseBox.FillColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.MinimiseBox.HoverState.Parent = Me.MinimiseBox
        Me.MinimiseBox.IconColor = System.Drawing.Color.White
        Me.MinimiseBox.Location = New System.Drawing.Point(159, 0)
        Me.MinimiseBox.Name = "MinimiseBox"
        Me.MinimiseBox.ShadowDecoration.Parent = Me.MinimiseBox
        Me.MinimiseBox.Size = New System.Drawing.Size(25, 25)
        Me.MinimiseBox.TabIndex = 3
        '
        'CloseBox
        '
        Me.CloseBox.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CloseBox.Animated = True
        Me.CloseBox.FillColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.CloseBox.HoverState.Parent = Me.CloseBox
        Me.CloseBox.IconColor = System.Drawing.Color.White
        Me.CloseBox.Location = New System.Drawing.Point(184, 0)
        Me.CloseBox.Name = "CloseBox"
        Me.CloseBox.ShadowDecoration.Parent = Me.CloseBox
        Me.CloseBox.Size = New System.Drawing.Size(25, 25)
        Me.CloseBox.TabIndex = 2
        '
        'FormLabel
        '
        Me.FormLabel.AutoSize = True
        Me.FormLabel.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.FormLabel.Location = New System.Drawing.Point(23, 6)
        Me.FormLabel.Name = "FormLabel"
        Me.FormLabel.Size = New System.Drawing.Size(87, 13)
        Me.FormLabel.TabIndex = 0
        Me.FormLabel.Text = "ExLogin | V1.2.0"
        '
        'FormDrag
        '
        Me.FormDrag.TargetControl = Me.FormPanel
        '
        'LabelDrag
        '
        Me.LabelDrag.TargetControl = Me.FormLabel
        '
        'Username
        '
        Me.Username.BorderColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Username.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Username.DefaultText = "Username"
        Me.Username.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Username.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(33, Byte), Integer))
        Me.Username.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Username.DisabledState.Parent = Me.Username
        Me.Username.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Username.FillColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(33, Byte), Integer))
        Me.Username.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Username.FocusedState.Parent = Me.Username
        Me.Username.ForeColor = System.Drawing.Color.White
        Me.Username.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Username.HoverState.Parent = Me.Username
        Me.Username.Location = New System.Drawing.Point(1, 26)
        Me.Username.Name = "Username"
        Me.Username.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Username.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(134, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.Username.PlaceholderText = "Username"
        Me.Username.SelectedText = ""
        Me.Username.SelectionStart = 8
        Me.Username.ShadowDecoration.BorderRadius = 3
        Me.Username.ShadowDecoration.Depth = 10
        Me.Username.ShadowDecoration.Parent = Me.Username
        Me.Username.Size = New System.Drawing.Size(207, 25)
        Me.Username.TabIndex = 2
        Me.Username.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Password
        '
        Me.Password.BorderColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Password.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Password.DefaultText = "Password"
        Me.Password.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Password.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(33, Byte), Integer))
        Me.Password.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Password.DisabledState.Parent = Me.Password
        Me.Password.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Password.FillColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(33, Byte), Integer))
        Me.Password.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Password.FocusedState.Parent = Me.Password
        Me.Password.ForeColor = System.Drawing.Color.White
        Me.Password.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Password.HoverState.Parent = Me.Password
        Me.Password.Location = New System.Drawing.Point(1, 52)
        Me.Password.Name = "Password"
        Me.Password.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Password.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(134, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.Password.PlaceholderText = "Password"
        Me.Password.SelectedText = ""
        Me.Password.SelectionStart = 8
        Me.Password.ShadowDecoration.BorderRadius = 3
        Me.Password.ShadowDecoration.Depth = 10
        Me.Password.ShadowDecoration.Parent = Me.Password
        Me.Password.Size = New System.Drawing.Size(207, 25)
        Me.Password.TabIndex = 3
        Me.Password.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Password.UseSystemPasswordChar = True
        '
        'MainButton
        '
        Me.MainButton.Animated = True
        Me.MainButton.BorderColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.MainButton.CheckedState.Parent = Me.MainButton
        Me.MainButton.CustomImages.Parent = Me.MainButton
        Me.MainButton.FillColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.MainButton.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MainButton.ForeColor = System.Drawing.Color.White
        Me.MainButton.HoverState.Parent = Me.MainButton
        Me.MainButton.Location = New System.Drawing.Point(1, 78)
        Me.MainButton.Name = "MainButton"
        Me.MainButton.ShadowDecoration.Parent = Me.MainButton
        Me.MainButton.Size = New System.Drawing.Size(207, 25)
        Me.MainButton.TabIndex = 4
        Me.MainButton.Text = "Login"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(2, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(22, 22)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 7
        Me.PictureBox1.TabStop = False
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(33, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(209, 104)
        Me.Controls.Add(Me.MainButton)
        Me.Controls.Add(Me.Password)
        Me.Controls.Add(Me.Username)
        Me.Controls.Add(Me.FormLabel)
        Me.Controls.Add(Me.FormPanel)
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ExLogin - By Roni"
        Me.FormPanel.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents FormPanel As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents FormLabel As Label
    Friend WithEvents FormDrag As Guna.UI2.WinForms.Guna2DragControl
    Friend WithEvents CloseBox As Guna.UI2.WinForms.Guna2ControlBox
    Friend WithEvents MinimiseBox As Guna.UI2.WinForms.Guna2ControlBox
    Friend WithEvents LabelDrag As Guna.UI2.WinForms.Guna2DragControl
    Friend WithEvents Username As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Password As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents MainButton As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents PictureBox1 As PictureBox
End Class
