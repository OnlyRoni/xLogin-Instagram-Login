﻿Imports xNet, Newtonsoft.Json.Linq, System.Net
Public Class MainForm
    Dim Cookies As String
#Region "Main Functions"
    Function Login(Username As String, Password As String) As Boolean
        Dim Response As String = ""
        Using Request As HttpRequest = New HttpRequest
            With Request
                .IgnoreProtocolErrors = True
                .UserAgent = "Instagram 100.1.0.29.135 Android"
                .AddParam("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                .AddParam("username", Username)
                .AddParam("password", Password)
                .AddParam("device_id", Guid.NewGuid.ToString)
                .AddParam("login_attempt_count", "0")
            End With
            Dim RequestInfo = Request.Post("https://i.instagram.com/api/v1/accounts/login/")
            Dim RequestCookies = RequestInfo.Cookies
            Cookies = ""
            For Each Cookie In RequestCookies
                Cookies = $"{Cookies}{Cookie.Key}={Cookie.Value}; "
            Next
            Response = RequestInfo.ToString
        End Using
        If Response.Contains("""logged_in_user""") Then
            MsgBox($"Login was successfull!{vbNewLine}{vbNewLine}{Response}", MsgBoxStyle.Information)
            Return True
        ElseIf Response.Contains("""bad_password""") Or Response.Contains("""rate_limit_error""") Then
            MsgBox($"Login has failed...{vbNewLine}{vbNewLine}{Response}", MsgBoxStyle.Information)
            Return False
        ElseIf Response.Contains("""challenge_required""") Then
            Dim ChallengeURL As String = JObject.Parse(Response)("challenge")("api_path") : Dim SusLoginAccountInfo As String = SecureInfo(ChallengeURL)
            Dim Email As String = JObject.Parse(SusLoginAccountInfo)("step_data")("email") : If Email = "" Then Email = "None"
            Dim Phone_Number As String = JObject.Parse(SusLoginAccountInfo)("step_data")("phone_number") : If Phone_Number = "" Then Phone_Number = "None"
            Dim Choice As String = InputBox($"How do you want to receive your code?{vbNewLine}{vbNewLine}[1] Email: {Email}{vbNewLine}[2] Phone Number: {Phone_Number}", "Suspitious Login", "Choice")
            If SendSecureChoice(ChallengeURL, Choice) Then
                Dim Code As String = InputBox("Enter the 6-digit code we sent to you.", "Suspitious Login", "Code") : Dim SendCode As String = SendSecurityCode(ChallengeURL, Code)
                If SendCode.Contains("""logged_in_user""") Then
                    MsgBox($"Login was successfull!{vbNewLine}{vbNewLine}{SendCode}", MsgBoxStyle.Information)
                    Return True
                Else
                    MsgBox($"Login has failed...{vbNewLine}{vbNewLine}{SendCode}", MsgBoxStyle.Information)
                    Return False
                End If
            Else
                MsgBox($"Login has failed...{vbNewLine}{vbNewLine}Code send error!", MsgBoxStyle.Information)
                Return False
            End If
        ElseIf Response.Contains("""two_factor_required""") Then
            MsgBox($"Login has failed...{vbNewLine}{vbNewLine}Two factor authentication encountered!", MsgBoxStyle.Information)
            Return False
        Else
            MsgBox(Response)
            Return False
        End If
    End Function
    Function SendSecureChoice(Url As String, Choice As String) As Boolean
        Dim Response = ""
        Using Request As HttpRequest = New HttpRequest
            With Request
                .IgnoreProtocolErrors = True
                .UserAgent = "Instagram 100.1.0.29.135 Android"
                .AddParam("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                .AddHeader("Cookie", Cookies)
                .AddParam("choice", Choice)
            End With
            Response = Request.Post($"https://i.instagram.com/api/v1{Url}").ToString
        End Using
        If Response.Contains("""security_code"":""None"",") Then
            Return True
        Else
            Return False
        End If
    End Function
    Function SendSecurityCode(Url As String, Code As String) As String
        Dim Response = ""
        Using Request As HttpRequest = New HttpRequest
            With Request
                .IgnoreProtocolErrors = True
                .UserAgent = "Instagram 100.1.0.29.135 Android"
                .AddParam("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                .AddHeader("Cookie", Cookies)
                .AddParam("security_code", Code)
            End With
            Dim RequestInfo = Request.Post($"https://i.instagram.com/api/v1{Url}")
            Dim RequestCookies = RequestInfo.Cookies
            Cookies = ""
            For Each Cookie In RequestCookies
                Cookies = $"{Cookies}{Cookie.Key}={Cookie.Value}; "
            Next
            Response = RequestInfo.ToString
        End Using
        Return Response
    End Function
    Function SecureInfo(Url As String) As String
        Dim WebClient As WebClient = New WebClient()
        With WebClient
            .Headers.Add(HttpRequestHeader.AcceptLanguage, "en-US,en;q=0.9,ar-EG;q=0.8,ar;q=0.7,bas-CM;q=0.6,bas;q=0.5")
            .Headers.Add(HttpRequestHeader.Accept, "*/*")
            .Headers.Add(HttpRequestHeader.ContentType, "application/x-www-form-urlencoded; charset=UTF-8")
            .Headers.Add(HttpRequestHeader.UserAgent, "Instagram 100.1.0.29.135 Android")
            .Headers.Add($"Cookie: {Cookies}")
        End With
        Try
            Return WebClient.DownloadString($"https://i.instagram.com/api/v1{Url}")
        Catch ex As WebException
            Return Nothing
        End Try
    End Function
#End Region
#Region "Buttons"
    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox($"Coded fully by Roni.{vbNewLine}+ Instagram: @xexx{vbNewLine}+ Github: github.com/0nlyRoni")
    End Sub
    Private Sub MainButton_Click(sender As Object, e As EventArgs) Handles MainButton.Click
        Login(Username.Text, Password.Text)
    End Sub
#End Region
End Class


